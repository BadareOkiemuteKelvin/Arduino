﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;

namespace SCADA_APPLICATION
{
    public partial class Form1 : Form
    {

        private SerialPort serialPort;
        public Form1()
        {
            
            InitializeComponent();
            serialPort = new SerialPort();
            serialPort.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);

            // Optionally list available COM ports
            string[] ports = SerialPort.GetPortNames();
            comboBox1.Items.AddRange(ports);
            button2.Enabled = false;
        }
        private void DataReceivedHandler(object sender, SerialDataReceivedEventArgs e)
        {
            string data = serialPort.ReadLine(); // Read data
            string [] processData= data.Split(',');
            string part1 = processData[0];
            string part2 = processData[1];
            string part3 = processData[2];
            string part4 = processData[3];
            string part5 = processData[4];
            string part6 = processData[5];
            this.Invoke(new Action(() =>
            {
                pictureBox1.Height = Convert.ToInt32(280.0 - ((Convert.ToDouble(part2)/32.0) * 280.0));
                pictureBox3.Height = Convert.ToInt32(280.0 - ((Convert.ToDouble(part3) / 100.0) * 280.0));
                textBox1.Text =part2;
                textBox2.Text = part3;
                textBox5.Text = part5;
                textBox4.Text = part6;
                label11.Text = part1;
                label22.Text = part4;



            }





            ));
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pictureBox1.Height = 280;
            textBox1.Text = "0";
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

       

     
        private void button1_Click(object sender, EventArgs e)//Connect
        {
            if ((comboBox1.Text != "" )&& (comboBox2.Text !=""))
            {
                serialPort.PortName = comboBox1.SelectedItem.ToString();
                serialPort.BaudRate = Convert.ToInt32(comboBox2.SelectedItem);
                
                try
                {
                    serialPort.Open();
                    button1.Enabled = false;
                    button2.Enabled = true;
                    serialPort.WriteLine("START");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Error , Please select a port");
            }

        }

        private void button3_Click(object sender, EventArgs e)//Connect
        { 
        
        }

        private void button4_Click(object sender, EventArgs e)//Connect
        {

        }


        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (serialPort.IsOpen)
            {
                serialPort.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)//Close Port
        {
            serialPort.Close();
            button1.Enabled = true;
            button2.Enabled = false;
            MessageBox.Show("Port closed successfully.");
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }





        // Setpoint for level

        private void button3_Click_1(object sender, EventArgs e)
        {
            if ((comboBox1.Text != "") && (comboBox2.Text != ""))
            {
                serialPort.PortName = comboBox1.SelectedItem.ToString();
                serialPort.BaudRate = Convert.ToInt32(comboBox2.SelectedItem);

                try
                {
                    serialPort.Open();
                    serialPort.WriteLine(textBox4.Text + "," + "L");
                    serialPort.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Error , Please select a port");
            }
        }

        // TEMP SET POINT
        private void button4_Click_1(object sender, EventArgs e)
        {
            if ((comboBox1.Text != "") && (comboBox2.Text != ""))
            {
                serialPort.PortName = comboBox1.SelectedItem.ToString();
                serialPort.BaudRate = Convert.ToInt32(comboBox2.SelectedItem);

                try
                {
                    serialPort.Open();
                    serialPort.WriteLine(textBox5.Text + "," + "T");
                    serialPort.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Error , Please select a port");
            }
        }

        private void DISPLAY_Enter(object sender, EventArgs e)
        {

        }
    }
}
